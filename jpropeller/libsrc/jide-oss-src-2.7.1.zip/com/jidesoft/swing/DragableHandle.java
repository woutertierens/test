/*
 * @(#) DragableHandle.java
 * Last modified date: 2/9/2005
 *
 * Copyright 2002 - 2005 JIDE Software Inc. All rights reserved.
 */
package com.jidesoft.swing;

/**
 * An interface to indicate a component can be used as a handle to be drag.
 */
public interface DragableHandle {
}
